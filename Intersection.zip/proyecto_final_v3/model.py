"""
Implementación a partir de boid_flockers por Craig Reynolds's en https://github.com/projectmesa/mesa/blob/main/examples/boid_flockers/boid_flockers/model.py
"""
import numpy as np
from mesa import Model
from mesa.space import ContinuousSpace
from mesa.time import RandomActivation
from agents import Vehicle
from agents import Horizontal
from agents import Vertical
from agents import Semaforo


class Intersection(Model):

    #Modelo interseccion. Se encarga de la creacion de modelos, posicionamiento y manejo.


    def __init__(self,population=4,width=25,height=25,speed=3,vision=5,separation=1,cohere=0.0125,separate=0.125,match=0.02):
        self.population = population
        self.vision = vision
        self.speed = speed
        self.separation = separation
        self.schedule = RandomActivation(self)
        self.space = ContinuousSpace(width, height, True)
        self.factors = dict(cohere=cohere, separate=separate, match=match)
        self.make_agents()
        self.running = True

    def make_agents(self):

        #Crear los agentes de self.population, con posiciones definidas y variables inicializadas
        velX = [0, 1, 0, 1]
        velY = [1, 0, 1, 0]
        posY = [0.5, 10.0, 24.5, 15.0]
        posX = [10.0, 24.5, 15.0, 0.5]

        for i in range(self.population):
            y = posY[i]
            x = posX[i]
            pos = np.array((x, y))
            velocity = [velX[i], velY[i]]
            vehicle = Vehicle(i, self,pos, self.speed,velocity,self.vision,self.separation,**self.factors)
            self.space.place_agent(vehicle, pos)
            self.schedule.add(vehicle)


        #Crear las calles

        pos1 = np.array((12.5,12.5))
        path1 = Horizontal(50,self,pos1)
        pos2 = np.array((12.5,12.5))
        path2 = Vertical(55.5,self,pos2)
        self.space.place_agent(path1, pos1)
        self.space.place_agent(path2, pos2)
        self.schedule.add(path1)
        self.schedule.add(path2)


        #Crear semaforos

        l1 = Semaforo(1101,self,np.array((12.5,10.0)),2)
        l2 = Semaforo(1102,self,np.array((10.0,12.5)),2)
        l3 = Semaforo(1103,self,np.array((12.5,15.0)),2)
        l4 = Semaforo(1104,self,np.array((15.0,12.5)),2)
        self.space.place_agent(l1, np.array((12.5,10.0)))
        self.space.place_agent(l2, np.array((10.0,12.5)))
        self.space.place_agent(l3, np.array((12.5,15.0)))
        self.space.place_agent(l4, np.array((15.0,12.5)))
        self.schedule.add(l1)
        self.schedule.add(l2)
        self.schedule.add(l3)
        self.schedule.add(l4)

    def step(self):
        self.schedule.step()
        posicion = []
        for i in range(self.population):
            xy = self.schedule.agents[i].pos
            p = [xy[0], xy[1], 0]
            posicion.append(p)
        return posicion
