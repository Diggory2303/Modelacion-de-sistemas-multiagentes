"""
Código creado a partir de "boid.py" de Sergio Ruiz
https://github.com/sergioruiz/tc2008b/blob/main/boid.py
y de boid_flockers en https://github.com/projectmesa/mesa/blob/main/examples/boid_flockers/boid_flockers/boid.py
"""
import numpy as np
import random

from mesa import Agent


class Vehicle(Agent):
    """
    fuente: boid_flockers
    """

    def __init__(self, unique_id, model, pos, speed, velocity, vision, separation, cohere=0.025, separate=0.25,
                 match=0.04):
        super().__init__(unique_id, model)
        self.pos = np.array(pos)
        self.speed = speed
        self.velocity = velocity
        self.vision = vision
        self.separation = separation
        self.cohere_factor = cohere
        self.separate_factor = separate
        self.match_factor = match
        self.typeOf = 0

    def cohere(self, neighbors):
        cohere = np.zeros(2)
        if neighbors:
            for neighbor in neighbors:
                cohere += self.model.space.get_heading(self.pos, neighbor.pos)
            cohere /= len(neighbors)
        return cohere

    def separate(self, neighbors):
        me = self.pos
        them = (n.pos for n in neighbors)
        separation_vector = np.zeros(2)
        for other in them:
            if self.model.space.get_distance(me, other) < self.separation:
                separation_vector -= self.model.space.get_heading(me, other)
        return separation_vector

    def match_heading(self, neighbors):
        match_vector = np.zeros(2)
        if neighbors:
            for neighbor in neighbors:
                match_vector += neighbor.velocity
            match_vector /= len(neighbors)
        return match_vector

    def step(self):
        neighborsBefore = self.model.space.get_neighbors(self.pos, self.vision, False)
        neighbors = []
        neighborsTraffic = []
        suma = self.cohere(neighbors) * self.cohere_factor + self.separate(
            neighbors) * self.separate_factor + self.match_heading(neighbors) * self.match_factor / 2
        print("+=valor", suma)
        self.velocity += (
                                 self.cohere(neighbors) * self.cohere_factor
                                 + self.separate(neighbors) * self.separate_factor
                                 + self.match_heading(neighbors) * self.match_factor
                         ) / 2

        valor = np.linalg.norm(self.velocity)
        print(valor, "valor")

        for i in neighborsBefore:
            print("typeofN", i.typeOf)
            if i.typeOf == 2:
                neighborsTraffic.append(i)
        print(neighborsTraffic, "neighbors")
        self.velocity /= np.linalg.norm(self.velocity)
        random_number = random.randint(1, 5)
        print("randomNum", random_number)
        self.velocity /= random_number
        if (self.pos[0] == 30 or self.pos[1] == 20):
            new_pos = self.pos - self.velocity * self.speed
        else:
            new_pos = self.pos + self.velocity * self.speed
        self.model.space.move_agent(self, new_pos)

        TL = []
        if len(neighborsTraffic) > 0:
            for i in neighborsTraffic:
                if (self.pos[0] == 20):
                    if (i.pos[0] == 25 and i.pos[1] == 20):
                        TL.append(i)
                        if (TL[0].color == 1 and self.pos[1] < TL[0].pos[1]):
                            self.speed = 0
                        elif (TL[0].color == 2):
                            self.speed = 5
                            self.speed = 5 / 4
                        else:
                            self.speed = 5

                elif (self.pos[1] == 20):
                    if (i.pos[0] == 30 and i.pos[1] == 25):
                        TL.append(i)
                        if (TL[0].color == 1 and self.pos[0] > TL[0].pos[0]):
                            self.speed = 0
                        elif (TL[0].color == 2):
                            self.speed = 5
                            self.speed = 5 / 4
                        else:
                            self.speed = 5

                elif (self.pos[0] == 30):
                    if (i.pos[0] == 25 and i.pos[1] == 30):
                        TL.append(i)
                        if (TL[0].color == 1 and self.pos[1] > TL[0].pos[1]):
                            self.speed = 0
                        elif (TL[0].color == 2):
                            self.speed = 5
                            self.speed = 5 / 4
                        else:
                            self.speed = 5

                elif (self.pos[1] == 30):
                    if (i.pos[0] == 20 and i.pos[1] == 25):
                        TL.append(i)
                        if (TL[0].color == 1 and self.pos[0] < TL[0].pos[0]):
                            self.speed = 0
                        elif (TL[0].color == 2):
                            self.speed = 5
                            self.speed = 5 / 4
                        else:
                            self.speed = 5

                # Verticales
                if (self.pos[1] == 20 or self.pos[1] == 30):
                    if (self.pos[0] > 20 and self.pos[0] < 30):
                        if (i.pos[0] == 25 and i.pos[1] == 20):
                            i.color = 1
                        if (i.pos[0] == 25 and i.pos[1] == 30):
                            i.color = 1
                        if (i.pos[0] == 20 and i.pos[1] == 25):
                            i.color = 0
                        if (i.pos[0] == 30 and i.pos[1] == 25):
                            i.color = 0
                    else:
                        if (i.pos[0] == 25 and i.pos[1] == 20):
                            i.color = 2
                        if (i.pos[0] == 25 and i.pos[1] == 30):
                            i.color = 2
                # Horizontales
                if (self.pos[0] == 20 or self.pos[0] == 30):
                    if (self.pos[1] > 20 and self.pos[1] < 30):
                        if (i.pos[0] == 20 and i.pos[1] == 25):
                            i.color = 1
                        if (i.pos[0] == 30 and i.pos[1] == 25):
                            i.color = 1
                        if (i.pos[0] == 25 and i.pos[1] == 20):
                            i.color = 0
                        if (i.pos[0] == 25 and i.pos[1] == 30):
                            i.color = 0
                    else:
                        if (i.pos[0] == 20 and i.pos[1] == 25):
                            i.color = 2
                        if (i.pos[0] == 30 and i.pos[1] == 25):
                            i.color = 2


class Horizontal(Agent):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model)
        self.pos = np.array(pos)
        self.typeOf = 1
        self.orientation = 0


class Vertical(Agent):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model)
        self.pos = np.array(pos)
        self.typeOf = 1
        self.orientation = 1


class Semaforo(Agent):
    def __init__(self, unique_id, model, pos, color):
        super().__init__(unique_id, model)
        self.pos = np.array(pos)
        self.typeOf = 2
        self.color = color
