from mesa.visualization.ModularVisualization import ModularServer

from model import Intersection
from SimpleContinousModule import SimpleCanvas


def intersection_draw(agent):
    portrayal = {"Filled": "False"}

    # Calle Horizontal
    if agent.typeOf == 1 and agent.orientation == 0:
        portrayal["Shape"] = "rect"
        portrayal["Filled"] = "false"
        portrayal["Color"] = "black"
        portrayal["Layer"] = 0
        portrayal["w"] = 1
        portrayal["h"] = 0.15
    # Calle Vertical
    elif agent.typeOf == 1 and agent.orientation == 1:
        portrayal["Filled"] = "false"
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "black"
        portrayal["Layer"] = 0
        portrayal["w"] = 0.15
        portrayal["h"] = 1
    #Coches vertical
    elif agent.typeOf == 0 and (agent.pos[0] == 10.0 or agent.pos[0] == 15.0):
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "purple"
        portrayal["Layer"] = 1
        portrayal["w"] = 0.03
        portrayal["h"] = 0.06
    #Coches Horizontal
    elif agent.typeOf == 0 and (agent.pos[1] == 10.0 or agent.pos[1] == 15.0):
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "orange"
        portrayal["Layer"] = 1
        portrayal["w"] = 0.06
        portrayal["h"] = 0.03
    #Semaforos
    elif agent.typeOf == 2 and agent.pos[1] == 10 and agent.color == 0:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "green"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.15
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 10 and agent.color == 0:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "green"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.15
    elif agent.typeOf == 2 and agent.pos[1] == 15 and agent.color == 0:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "green"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.15
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 15 and agent.color == 0:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "green"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.15
    elif agent.typeOf == 2 and agent.pos[1] == 10 and agent.color == 1:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "red"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.15
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 10 and agent.color == 1:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "red"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.15
    elif agent.typeOf == 2 and agent.pos[1] == 15 and agent.color == 1:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "red"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.15
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 15 and agent.color == 1:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "red"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.15
    elif agent.typeOf == 2 and agent.pos[1] == 10 and agent.color == 2:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.15
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 10 and agent.color == 2:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.15
    elif agent.typeOf == 2 and agent.pos[1] == 15 and agent.color == 2:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.15
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 15 and agent.color == 2:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.15
    elif agent.typeOf == 2 and agent.pos[1] == 10 and agent.color == 3:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 10 and agent.color == 3:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    elif agent.typeOf == 2 and agent.pos[1] == 15 and agent.color == 3:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 15 and agent.color == 3:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    return portrayal


#Tamano canvas
intersection_canvas = SimpleCanvas(intersection_draw, 425, 425)

#Parametros iniciales
params = {
    "population": 4,
    "width": 25,
    "height": 25,
    "speed": 3,
    "vision": 5,
    "separation": 0.5,
}



server = ModularServer(Intersection, [intersection_canvas], "Intersección de Tráfico", params)

server.port = 8000
